from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey  # noqa
from sqlalchemy.orm import sessionmaker, relationship


engine = create_engine('sqlite:///database.db', connect_args={'check_same_thread': False})  # noqa
Session = sessionmaker(bind=engine)
db_session = Session()
Base = declarative_base()


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    username = Column(String, unique=True)
    email = Column(String, unique=True)
    password = Column(String)
    pic = Column(String, default='/static/imgs/person.png')
    reset_code = Column(String)

    def __repr__(self):
        return "<User(id={}, username={})>".format(self.id, self.username)


class Vote(Base):
    __tablename__ = 'votes'

    id = Column(Integer, primary_key=True)
    answer = Column(Integer, ForeignKey('answers.id'))
    user = Column(Integer, ForeignKey('users.id'))
    value = Column(Integer)

    def __repr__(self):
        return "<Vote(id={}, by={}, value={})>".format(self.id, self.user, self.value)  # noqa


class Answer(Base):
    __tablename__ = 'answers'

    id = Column(Integer, primary_key=True)
    user = Column(Integer, ForeignKey('users.id'))
    question = Column(Integer, ForeignKey('questions.id'))
    content = Column(String)
    votes = relationship("Vote", primaryjoin=id == Vote.answer)
    user_object = relationship("User", primaryjoin=user == User.id)
    is_correct = Column(Boolean)

    def total_votes(self):
        return sum([v.value for v in self.votes])

    def voted_users(self):
        return [v.user for v in self.votes]

    def __repr__(self):
        return "<Answer(id={}, content={})>".format(self.id, self.content)


class Question(Base):
    __tablename__ = 'questions'

    id = Column(Integer, primary_key=True)
    user = Column(Integer, ForeignKey('users.id'))
    title = Column(String)
    content = Column(String)
    answers = relationship("Answer", primaryjoin=id == Answer.question)
    user_object = relationship("User", primaryjoin=user == User.id)

    def total_votes(self):
        return sum([v.value for a in self.answers for v in a.votes])

    def is_answered(self):
        return len([a for a in self.answers if a.is_correct]) > 0

    def __repr__(self):
        return "<Question(id={}, content={})>".format(self.id, self.content)


def init_db():
    Base.metadata.create_all(engine)
