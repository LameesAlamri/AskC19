import joblib

from haystack import Finder
from haystack.reader.farm import FARMReader
from haystack.document_store.memory import InMemoryDocumentStore
from haystack.retriever.sparse import TfidfRetriever


import nltk
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
from nltk import word_tokenize

# download nltk data
# nltk.download('stopwords')
# nltk.download('punkt')


# initiate stemmer and stopwords set
stemmer = PorterStemmer()
stopwords = set(stopwords.words('english'))

finder = None


def preprocess_text(text):
    '''
    this function will preprocess any text passed to it by
    stem and remove stop words
    '''
    text = text.lower()
    return " ".join([stemmer.stem(w) for w in word_tokenize(text) if w not in stopwords])  # noqa


def init_engine():
    global finder
    # read dataset
    dicts = joblib.load('dicts.joblib.compressed')
    dicts = dicts[:1000]
    # [{title: '', context: '',}, {}, {} , ...]

    # initiate Store
    document_store = InMemoryDocumentStore()
    document_store.write_documents(dicts)

    # feed model
    retriever = TfidfRetriever(document_store=document_store)
    reader = FARMReader(model_name_or_path="deepset/bert-base-cased-squad2", use_gpu=False)  # noqa
    finder = Finder(reader, retriever)


def predict(question, top_k_retriever=4, top_k_reader=4, preproces=False):
    global finder
    '''
    Predict the answer of passed question
    if preproces paramters is set to True, then apply preprocess_text
    on question
    '''
    if(preproces):
        question = preprocess_text(question)

    # {answers: [{context: answer, probability: 0.8, ..}, {...}, {..}]}
    prediction = finder.get_answers(
            question=question,
            top_k_retriever=top_k_retriever,
            top_k_reader=top_k_reader
            )
    # [(ans1, prob1), (ans2, prob2), (ans3, prob3), ...]
    answers = [(answer['context'], round(answer['probability'] * 100, 3)) for answer in prediction['answers']]  # noqa
    return answers
