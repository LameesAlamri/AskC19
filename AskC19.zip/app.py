from flask import Flask, render_template, request, session, redirect
from flask_session import Session
from engine import predict, init_engine
from models import init_db, User, Question, Answer, Vote
from models import db_session
from flask_mail import Mail, Message
import uuid
import os
import random

init_db()

app = Flask('Ask-C19')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = 'some_key'
# mail section
# If using STARTTLS with MAIL_USE_TLS = True, then use MAIL_PORT = 587.
# If using SSL/TLS directly with MAIL_USE_SSL = True, then use MAIL_PORT = 465.
app.config['MAIL_SERVER'] = "smtp.gmail.com"
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True
# steps to active mail sending from gmail: https://stackoverflow.com/a/62954542
app.config['MAIL_USERNAME'] = "It491project@gmail.com"
app.config['MAIL_PASSWORD'] = "abcd*12345"

Session(app)
mail = Mail(app)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html', session=session)


@app.route('/register', methods=['GET', 'POST'])
def register():
    data = {'errs': []}
    if(session.get('user')):
        return redirect('/')
    # check if user submit the form
    if request.method == 'POST':
        # get form values (inputs)
        pic = request.files.get('img', None)
        username = request.form.get('username', '').strip().lower()
        name = request.form.get('name', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        pass1 = request.form.get('pass1', '').strip()
        pass2 = request.form.get('pass2', '').strip()
        # check picture file
        if pic.filename:
            if pic.filename.split('.')[-1].lower() not in ALLOWED_EXTENSIONS:
                data['errs'].append('File selected is not allowed.')
        # check email
        if email == '':
            data['errs'].append('Enter your email.')
        # cehck email existance
        else:
            users = db_session.query(User).filter(User.email == email).all()
            if(len(users) > 0):
                data['errs'].append('email is already exists.')
        # check username and name
        if len(username) < 3 or len(name) < 3:
            data['errs'].append('name/username should be 3 letters at least.')
        # check username existance
        else:
            users = db_session.query(User).filter(User.username == username).all()  # noqa
            if(len(users) > 0):
                data['errs'].append('username is already exists.')
        # check password
        if len(pass1) < 3:
            data['errs'].append('password should be 3 letters at least.')
        # check the match of passwords
        elif pass1 != pass2:
            data['errs'].append('passwords does not match.')
        # if there is no errors, then register the user
        if(not data['errs']):
            # register new user
            # upload image
            pic_path = ''
            if pic.filename != '':
                pic_path = os.path.join('static', 'uploads', 'pics', str(uuid.uuid4()) + '.jpg')  # noqa
                pic.save(pic_path)
            # create user
            new_user = User(
                name=name,
                username=username,
                email=email,
                password=pass1,
                pic=pic_path)
            # add user to db
            db_session.add(new_user)
            db_session.commit()
            # redirect to login page
            return redirect('/login')
        # last values inserted by user
        data['username'] = username
        data['email'] = email
        data['name'] = name
        data['pass1'] = pass1
        data['pass2'] = pass2
    return render_template('register.html', session=session, data=data)


@app.route('/login', methods=['GET', 'POST'])
def login():
    data = {'err': ''}
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lower()
        password = request.form.get('pass', '').strip().lower()
        user = db_session.query(User).filter(User.username == username, User.password == password).first()  # noqa
        if not user:
            data['err'] = 'Password or username is not correct.'
        else:
            session['user'] = {'id': user.id, 'username': user.username}
            return redirect('/')
        data['username'] = username
        data['pass'] = password
    return render_template('login.html', session=session, data=data)


@app.route('/settings', methods=['POST', 'GET'])
def settings():
    data = {'errs': []}
    user = db_session.query(User).filter(User.id == session['user']['id']).first()  # noqa
    # check if user submit the form
    if request.method == 'POST':
        # get form values (inputs)
        pic = request.files.get('img', None)
        username = request.form.get('username', '').strip().lower()
        name = request.form.get('name', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        pass1 = request.form.get('pass1', '').strip()
        pass2 = request.form.get('pass2', '').strip()
        # check picture file
        if pic.filename:
            if pic.filename.split('.')[-1].lower() not in ALLOWED_EXTENSIONS:
                data['errs'].append('File selected is not allowed.')
        # check email
        if email == '':
            data['errs'].append('Enter your email.')
        # cehck email existance
        else:
            users = db_session.query(User).filter(User.email == email)  # noqa
            ids = [u.id for u in users]
            if(ids and session['user']['id'] not in ids):
                data['errs'].append('email is already exists.')
        # check username and name
        if len(username) < 3 or len(name) < 3:
            data['errs'].append('name/username should be 3 letters at least.')
        # check username existance
        else:
            users = db_session.query(User).filter(User.username == username).all()  # noqa
            ids = [u.id for u in users]
            if(ids and session['user']['id'] not in ids):
                data['errs'].append('username is already exists.')
        # check password
        if(pass1):
            if len(pass1) < 3:
                data['errs'].append('password should be 3 letters at least.')
            # check the match of passwords
            elif pass1 != pass2:
                data['errs'].append('passwords does not match.')
        # if there is no errors, then register the user
        if(not data['errs']):
            # register new user
            # upload image
            pic_path = ''
            if pic.filename:
                pic_path = os.path.join('static', 'uploads', 'pics', str(uuid.uuid4()) + '.jpg')  # noqa
                pic.save(pic_path)
            # create user
            user.name = name
            user.username = username
            if(pass1):
                user.password = pass1
            user.email = email
            if(pic.filename):
                user.pic = pic_path
            db_session.commit()
            data['msg'] = 'All changes successfully saved.'
        # last values inserted by user
    data['pic'] = user.pic
    data['username'] = user.username
    data['email'] = user.email
    data['name'] = user.name
    return render_template('settings.html', session=session, data=data)


@app.route('/questions/<by>', methods=['GET', 'POST'])
def questions(by):
    q = request.args.get('q', '')
    q = f'%{q}%'
    if(not session['user']):
        return redirect('/login')
    session['last_url'] = '/questions/' + by
    if(by != 'all' and by.isnumeric()):
        questions = db_session.query(Question).filter(Question.user == int(by)).order_by(Question.id.desc()).all()  # noqa
    else:
        questions = db_session.query(Question).filter(Question.title.like(q)).order_by(Question.id.desc()).all()  # noqa
    data = {"questions": questions, 'by': by}
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        if title:
            new_question = Question(
                user=session['user']['id'],
                title=title,
                content=content,
            )
            db_session.add(new_question)
            db_session.commit()
            data['msg'] = 'Question successfully posted!.'
        else:
            data['err'] = 'title is required.'
    return render_template('questions.html', session=session, data=data)


@app.route('/question/<id>', methods=['GET', 'POST'])
def get_question(id):
    session['last_url'] = '/question/' + id
    data = {}
    question = db_session.query(Question).filter(Question.id == id).first()
    if not question:
        return redirect('/questions/all')
    if request.method == 'POST':
        data['err'] = ''
        data['msg'] = ''
        answer_content = request.form.get('content', '').strip()
        if not answer_content:
            data['err'] = 'content is required.'
        else:
            new_answer = Answer(user=session['user']['id'], content=answer_content, question=id)  # noqa
            db_session.add(new_answer)
            db_session.commit()
            data['msg'] = 'Answer successfully posted.'
    data['question'] = question
    return render_template('question.html', session=session, data=data)


@app.route('/question/delete/<id>')
def del_question(id):
    question = db_session.query(Question).filter(Question.id == id).first()
    if question:
        for a in question.answers:
            db_session.delete(a)
        db_session.delete(question)
        db_session.commit()
    return redirect(session['last_url'])


@app.route('/vote/<id>/<vote_type>')
def vote(id, vote_type):
    current_votes = db_session.query(Vote).filter(Vote.answer == id, Vote.user == session['user']['id']).first()  # noqa
    if not current_votes:
        new_vote = Vote(user=session['user']['id'], answer=id)
        if vote_type == 'up':
            new_vote.value = 1
        else:
            new_vote.value = -1
        db_session.add(new_vote)
        db_session.commit()
    return redirect(session['last_url'])


@app.route('/my-answers')
def my_answers():
    session['last_url'] = '/my-answers'
    answers = db_session.query(Answer).filter(Answer.user == session['user']['id']).all()  # noqa
    for a in answers:
        a.question_object = db_session.query(Question).filter(Question.id == a.question).first()  # noqa
    return render_template('my-answers.html', session=session, answers=answers)


@app.route('/answer/delete/<id>')
def del_answer(id):
    answer = db_session.query(Answer).filter(Answer.id == id).first()
    if answer:
        db_session.delete(answer)
        db_session.commit()
    return redirect(session['last_url'])


@app.route('/answer/mark-answer/<id>')
def mark_answer(id):
    answer = db_session.query(Answer).filter(Answer.id == id).first()
    if answer:
        answer.is_correct = True
        db_session.commit()
    return redirect(session['last_url'])


@app.route('/logout')
def logout():
    session['user'] = None
    return redirect('/login')


@app.route("/forget", methods=['GET', 'POST'])
def forget():
    err = ''
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        user = db_session.query(User).filter(User.email == email).first()
        if (user):
            # create random code
            code = random.randint(100, 999)
            # save user code
            user.reset_code = code
            db_session.commit()
            # send mail
            msg = Message("Ask19 Reset Password Code")  # title
            msg.sender = app.config['MAIL_USERNAME']  # sender
            msg.recipients = [user.email]  # recipients list
            msg.body = "Your reset code is: " + user.reset_code  # mail body
            mail.send(msg)
            # redirect user ot reset page
            return redirect('/reset')
        else:
            err = 'Email not found.'
    return render_template("forget.html", session=session, err=err)


@app.route("/reset", methods=['GET', 'POST'])
def reset():
    err = ''
    msg = ''
    if (request.method == "POST"):
        code = request.form.get("code", "").strip()
        new_pass1 = request.form.get("new_pass1", "").strip()
        new_pass2 = request.form.get("new_pass2", "").strip()
        user = db_session.query(User).filter(User.reset_code == code).first()
        if (not user or code == ""):
            err = 'Invalid reset code.'
        elif (len(new_pass1) < 3):
            err = 'Password should be 3 letters at least'
        elif(new_pass1 != new_pass2):
            err = 'Passwords does not match'
        else:
            # change user password
            user.password = new_pass1
            user.reset_code = ""
            db_session.commit()
            msg = 'Password successfuly updated.'
    return render_template('reset.html', session=session, err=err, msg=msg)


@app.route('/answers', methods=['POST'])
def answers():
    err = ''
    answers = []
    question = request.form.get('question', '').strip()
    answers = predict(question, preproces=True)
    return render_template('answers.html', answers=answers, err=err, session=session)  # noqa


if __name__ == '__main__':
    init_engine()
    app.run(debug=True, use_reloader=False)
